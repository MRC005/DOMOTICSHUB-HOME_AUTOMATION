// document.getElementById("power-consumption").textContent = "120 kW";
document.getElementById("current-consumption").textContent = "200 W";

